//
//  ImangeChangeViewController.swift
//  Homework
//
//  Created by 谢子熠 on 2024/2/16.
//

import UIKit

class ImangeChangeViewController: UIViewController {
// MARK: - Outlet
// Imange
    @IBOutlet weak var ImangeChangeView: UIImageView!
// Last Button
    @IBOutlet weak var LastButton: UIButton!
// Next Button
    @IBOutlet weak var NextButton: UIButton!
    
    var imangeGroup = ["1", "2", "3", "4", "5"]
    var originNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        ImangeChangeView.image = UIImage(named: imangeGroup[originNum])
    }

    // MARK: -Action
    
    @IBAction func LastAction(_ sender: UIButton) {
        originNum += 1
        if originNum > 4 {
            originNum = 0
        }
    }
    
    @IBAction func NextAction(_ sender: UIButton) {
        ImangeChangeView.image = UIImage(named: imangeGroup[originNum])
    }
    
    // MARK: - Function
    func setUI() {
        // Button Setting
        LastButton.setTitle("Last", for: .normal)
        NextButton.setTitle("Next", for: .normal)
        // Image Setting
        ImangeChangeView.image = UIImage(named: imangeGroup[originNum])
        ImangeChangeView.isUserInteractionEnabled = true
        let tagGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        ImangeChangeView.addGestureRecognizer(tagGesture)
    }
    // MARK: - Object
    @objc func imangeTapped() {
        let imangeName = imangeGroup[originNum]
        let alertView = UIAlertAction(title: "Tapped", message: imangeName, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default)
        alertView.addAction(action)
        present(alertView, animated: true)
    }
}


