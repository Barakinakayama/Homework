//
//  ViewController.swift
//  Homework
//
//  Created by 谢子熠 on 2024/2/16.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

