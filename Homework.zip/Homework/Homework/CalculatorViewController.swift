//
//  CalculatorViewController.swift
//  Homework
//
//  Created by 谢子熠 on 2024/2/17.
//

import UIKit

class CalculatorViewController: UIViewController {
// MARK: - Outlet
    @IBOutlet weak var displayLabel: UILabel!
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    // MARK: - Action
    @IBAction func numberAction(_ sender: UIButton) {
        print(sender.tag)
    }
    // plus
    @IBAction func addAction(_ sender: UIButton) {
        
    }
    // minuse
    @IBAction func minuseAction(_ sender: UIButton) {
        
    }
    // equal
    @IBAction func equalAction(_ sender: UIButton) {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
